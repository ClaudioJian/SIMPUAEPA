# mapa-fullstack — merge manifest

Base: SIMPUAEPA-BackEnd
Frontend UI: mapa-front-backend / ACEX_project/WEB/Public_html

Precedence:
- ACEX_project/API -> Backend
- ACEX_project/WEB/Private -> Backend
- ACEX_project/WEB/config -> Backend
- ACEX_project/WEB/Public_html/* -> Frontend
- ACEX_project/WEB/Public_html/API -> Backend
- Other backend files/directories -> Backend

The frontend's ACEX_project/APP and its other non-Public_html files were intentionally not included.
