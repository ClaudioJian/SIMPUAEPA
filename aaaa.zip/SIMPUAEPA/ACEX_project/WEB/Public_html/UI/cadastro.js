const registerForm = document.getElementById('registerForm');

registerForm.addEventListener('submit', async function(event) {

    event.preventDefault();

    const name = registerForm.elements.name.value;
    const email = registerForm.elements.email.value;
    const password = registerForm.elements.password.value;
    const confirm_password = document.getElementById('confirm_password').value;


    if (password !== confirm_password) {
        alert("As senhas não coincidem! Por favor, verifique.");
        return;
    }

    const url = "/SIMPUAEPA/subscribe";

    const data = {
        name: name,
        email: email,
        password: password
    };

    
    try {

        const response = await fetch(url, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        console.log("HTTP:", response.status);
        console.log("Resposta:", result);

    } catch (error) {
        console.error("Erro na requisição:", error);
    }



});





// DARK MODE ABAIXO:
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.getElementById('themeIcon');

themeToggle.addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');

    if (document.body.classList.contains('dark-mode')) {
        themeIcon.src = "../images/dia-e-noite-white.png";
    } else {
        themeIcon.src = "../images/dia-e-noite.png";
    }
});